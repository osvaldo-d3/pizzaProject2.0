from django.urls import path

from . import views

urlpatterns = [
    path('', views.index),
    path('about/', views.about),
    path('contributors/', views.contributors),
    path('test/', views.test),
    path('form/', views.form), #That's what line 47 in views.py in app folder is telling us to do right there
    path('add-new/', views.newMembers), #If you see this a "hidden-route", for the back-end, it means you have errored out. Good practice to call it "add-new" because that's what your doing: your "posting"/adding something new. TiP: If your doing an edit then you might change 'add-new' to 'edit'. This is just for you to know what is going on here and know when you see these types of "paths" you are not supposed to see it, so-to-speak. 
    path('results/', views.results), #Results is here, wich is rendering (see views.py in app folder, lines 53 through 57/ 'results function'.) 
    path('the-shop/', views.theShop), #Make sure to "call it"/ use the same term here as you did in your other form.html (the-shop) and views.py (theShop) pages.
    path('reset/', views.reset),
    path('purchase/', views.purchase),
    path('pies/', views.pies),
    path('addNew/', views.addPie), #With this, we have rendered the form
    path('create/', views.create), #Now we give it the create method here
]


