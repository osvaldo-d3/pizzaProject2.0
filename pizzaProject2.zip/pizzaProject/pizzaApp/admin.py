from django.contrib import admin
from .models import Pies

# Register your models here.



admin.site.register(Pies)