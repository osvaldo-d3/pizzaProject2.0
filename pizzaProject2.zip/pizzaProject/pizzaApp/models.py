from django.db import models

# Create your models here.

class Pies(models.Model):
    pieName = models.CharField(max_length=45)
    pieType = models.CharField(max_length=45)
    pieStart = models.IntegerField()
    pieAdded = models.DateTimeField(auto_now_add=True)
    pieUpdated = models.DateTimeField(auto_now=True)

    
