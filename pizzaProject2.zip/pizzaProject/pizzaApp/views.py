from django.shortcuts import render, HttpResponse, redirect
import random
from .models import Pies 

# Create your views here.

#Here we created a 'Tokens' table, for all intensive purposes. The first token we called pizza and we said that our minimum value was 10 and our maximum value was 20. And so on and so forth.  
#These are our categories and their min/max prices
TOKENS = {
    "pizza": (10,20),
    "chickenWings": (5,10),
    "fountainDrinks": (2,4),
    "collectibles": (3,17),
}

#This is our index page that is pulling in some basic context/information and displaying it through our index.html
# main landing page
def index(request):
    context = {
        "pizzaName": "Ninja Pizza", #Translation: This is has a "key" (name of it): and a "value" (what it is actually set to). (Everything is alway done in pairs like this: this key/value method.)
        "pizzaLocation": "H-town, TX",
        "pizzaTypes": ["Pepporoni", "Sausage", "Ham", "Pineapple"] #this is an array that is called by our for loop in our index.html and then turned into a list
    }
    return render(request, "index.html", context) #This is saying: We're doing a return/ request and we're rendering it and requesting information from the index.html and we're also using something called 'context' that we called in the above code and this is how we're passing down information to our index page.
#The following two functions are not html pages. They are simply returning html responses and displaying the phrases in quotations.
# about page but not an html so no nav
def about(request):
    return HttpResponse("About our Project/Application")

# contributors page but not html so no nav
def contributors(request):
    return HttpResponse("This will show who contributed to the project and application")

#This is returning an HTML document, in this case, my jQuery page.
#jQuery page using html
def test(request):
    return render(request, "test.html")

             #Without Sessions and Redirect 
# def form(request):
#    return render(request, "pizzaform.html")
#     # if request.method == "GET":
#     #     print("GET request was made for pizzform.html") #this is like a console log
#     #     return render(request, "pizzaform.html")
#     # if request.method == "POST": #If this is a submit
#     #     print("POST request was made for pizzaform.html")

# def results(request):
#     if request.method == "POST":
#         context = {
#             'memberName': request.POST['memberName'],
#         }
#         return render(request, 'results.html', context) #the first three lines say that: if it sees a post request, it's going to post a context that is in our form (ie. memberName) and it's going to return the results page.
#     return render(request, 'results.html') #otherwise just return the results page

# the rest was built and migrate was done before testing

#This route is our form. This is going to render pizzaform.html
#main form page to add new member
def form(request):
        return render(request, 'pizzaform.html')# context)

#This is our extra route that we needed where we put our if request/statement. If everything is working correctly, you should never see this route in your browser address-bar.(see urls.py in app folder, line 11)      
# route to actually add a new member
def newMembers(request):
    if request.method == 'GET': #This is saying: if the request-method is Get request (which is the basic browser default)
        return redirect('/form/') #Translation: Then just redirect to form (form.html) If you see form 'path' in urls (under app folder), that's what this is telling us to do right there.
    request.session['results'] = { #if that's not it, then we move on to the next statement: Sessions. Meaning, we're using our "cash" (ie. Facebook keeping you logged in if you don't ever log out using your personal computer; sessions will never allow two browsers to be logged in at the same time under one web-browser(ie.Chrome)). . . (continued from line 49:  . . . and that is going to be put into 'sessions' and then (go to line 51) )
        'memberName': request.POST['memberName'], #Translation: 'key' (memberName): and our value is POST request called 'memberName'. So whatever happens to be put in this form is what would end be filled in here (request.POST . . .) And this is going to be the 'results' (see line 48). . .  
    }
    return redirect('/results') # . . . Then it's going to return and redirect to this 'results'. According to our urls (in app folder) , results is in urls.py (in app folder)(see urls.py in said folder). . .

#the page that displays the information entered on the new member form
def results(request):
    context = { #context is simply rendering the results . . .see line 57
        'results': request.session['results'],
    }
    return render(request, 'results.html', context) #. . . through our results.html page

# The main Ninja Pizza Shop page showing current total earned by the shop with the options to purchase items and add to the total
def theShop(request):
    if not "price" in request.session:
        request.session['price'] = 0
    return render(request, 'ninjaPizzaShop.html')

#This 'reset' function your going to want and use alot of
# clear shop total earned 
def reset(request):
    request.session.clear() #TiP:This line you would use if you would want a log-out ability
    return redirect('/the-shop/')
#Brain-storming: We know that in our views we have the above funciton (theShop) and we know we need the 'newMembers' function (above). 
#We need to make sure that we have our: "If it's just a 'GET' request then display this other wise we're going to do this" type of process (referring to 'newMembers' function).
#We can put our next function inside the (above) function, . . . however let's just make a new function!:

# route to actually add to our total
def purchase(request): #Double-check in your ninjaPizzaShop.html page to see what term you used after the form action tags.
    if request.method == 'GET': #Translation: if clicked ont the link to this pagei, we're doing a 'GET' request; we haven't submitted any forms yet.
        return redirect('/the-shop/') #Check your urls in app folder to see what you called the shop and use that same term here.
#Here is where all the 'POST' stuff comes in
    itemName = request.POST['categories'] #You can call 'itemName' anything you want; we are choosing to call it 'itemName' here. . . .'categories' is what we called a 'name' in our ninjaPizzaShop.html (in our divs). . . Translation: We're going to do a 'POST' from the categories, but we're going to be choosing a specific category.
    categories = TOKENS[itemName] #Translation: When we choose a category, the category is going to be equal to whatever the itemName that we pushed the button for. 

    currTotal = random.randint(categories[0], categories[1]) #Translation: Because we have two numbers listed in our 'TOKENS' "table" (see top page, line 6 through 10), we have to have index 0 and index 1, so it goes between the two numbers in the said table, it's going to give us a random number between those numbers in the table.

    result = 'total' #This we could use for styling later (ie. style your letters/ words in different colors like red for "withdrawal" and green for "deposit". It would give you the availability for a class.

    request.session['price'] += currTotal #Now we actually start to connect our buttons.
    return redirect('/the-shop')

#Display our newly added Pies
def pies(request):
    context = {
        "allPies": Pies.objects.all().values()
    }
    return render(request, 'pies.html', context)

def addPie(request):
    return render(request, 'newPies.html')

def create(request):
    Pies.objects.create(
        pieName=request.POST['pieName'],
        pieType=request.POST['pieType'],
        pieStart=request.POST['pieStart']
    )

    return redirect('/pies/')
