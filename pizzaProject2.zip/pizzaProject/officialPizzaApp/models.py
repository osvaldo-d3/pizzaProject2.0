from django.db import models
from django.db.models.base import Model
from django.db.models.deletion import CASCADE
import re

# Create your models here.

#Best Practice, build in order from one-to-one (first) through many-to-many(last).

#one to one relationship
class Pizza(models.Model):
    pizzaName = models.CharField(max_length=45)
    pizzaLocation = models.CharField(max_length=255)
    pizzaCreatedAt = models.DateTimeField(auto_now_add=True)
    pizzaUpdatedAt = models.DateTimeField(auto_now=True)

#one to many relationship
class Pie(models.Model):
    pieName = models.CharField(max_length=45)
    pieType = models.CharField(max_length=45)
    pieStart = models.IntegerField()
    pizza = models.ForeignKey(Pizza, related_name='pies', on_delete=models.CASCADE)

class Employee(models.Model):
    firstName = models.CharField(max_length=45)
    lastName =models.CharField(max_length=45)
    email = models.EmailField(unique=True)
    pizza = models.ForeignKey(Pizza, related_name='employees', on_delete=models.CASCADE)

class Shop(models.Model):
    shopName = models.CharField(max_length=45)
    shopDescription = models.CharField(max_length=255)
    shopPizza = models.ManyToManyField(Pizza, related_name='pizzaShop')
    #Here, no foregin key or CASCADE!

class GameManager(models.Manager):
    def validate(self, form): 
        errors = {}
        if len(form['gameName']) < 5:
            errors['gameName'] = 'Please have atleast 5 characters in the game name'
        gameNameCheck = self.filter(gameName=form['gameName'])
        if gameNameCheck:
            errors['gameName'] = 'That Game is already in the system Please choose a new name'
        return errors

class Game(models.Model):
    gameName = models.CharField(max_length=45)
    gameInfo = models.CharField(max_length=255)
    pizza = models.ForeignKey(Pizza, related_name='games', on_delete=models.CASCADE)

    objects = GameManager()

class UserManager(models.Manager):
    def validate(self, form):
        errors = {}
        if len(form['firstName']) <2:
            error['firstName'] = "First Name must be atleast 2 characters"
        if len(form['lastName']) <2:
            error['lastName'] = "Last Name must be at least 2 characters"
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(form['email']):
            errors['email'] = 'Invalid Email Format'

        emailCheck = self.filter(email=form['email'])
        if emailCheck:
            errors['email'] = 'Email address is already in use'

        usernameCheck = self.filter(username=form['username'])
        if usernameCheck:
            errors['username'] = 'Sorry that username has been taken please choose a different one'

        if len(form['password']) < 5:
            errors['password'] = 'Password must be atleast  5 characters long'

        if form['password'] != form['confrim']:
            errors['password'] = 'Passwords do not match'

        return errors

class User(models.Model):
    firstName = models.CharField(max_length=45)
    lastName = models.CharField(max_length=45)
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=45)
    password = models.CharField(max_length=45)

    objects = UserManager()

class Note(models.Model):
    noteTitle = models.CharField(max_length=45)
    noteText = models.CharField(max_length=300)
    user = models.ForeignKey(User, related_name='notes', on_delete=models.CASCADE)





