from pizzaApp.views import create
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt

# Create your views here.
#Here we're displaying all our Pizza "Parlors"
def officialPizza(request):
    return render(request, 'officialPizza.html')

#Landing page to view parlors
def allPizzas(request):
    context = {
        'pizzas': Pizza.objects.all()
    }
    return render(request, 'allPizzas.html', context)

#Here we create a Parlor via a hidden route
def createPizza(request):
    if request.method == "GET":
        return redirect('/pizza/createPizza/')
    Pizza.objects.create(
        pizzaName=request.POST['pizzaName'],
        pizzaLocation=request.POST['pizzaLocation']
    )
    return redirect('/pizza/thePizzas/')

#Landing page to edit/update a Parlor by pulling up one
def editPizza(request, pizza_id):
    oneParlor = Pizza.objects.get(id='pizza_id')
    context = {
        'editPizza': onePizza
    }
    return render(request, 'editPizza.html', context)

#hidden route to update Parlor ie.)Parlor's name
def updatePizza(request, pizza_id):
    toUpdate= Pizza.objects.get(id=pizza_id)
    toUpdate.pizzaName = request.POST['pizzaName']
    toUpdate.pizzaLocation = request.POST['pizzaLocation']
    toUpdate.save()

    return redirect('/pizza/thePizzas/')

#Delete a parlor
def deletePizza(request, pizza_id):
    toDelete = Pizza.objects.get(id=pizza_id)
    toDelete.delete()

    return redirect('/pizza/thePizzas/')

#Landing page to view all Pies
def allPies(request):
    context = {
        'pizzas': Pizza.objects.all()
    }
    return render(request, 'allPies.html', context)

# Hidden route to create Pie
def createPie(request):
    if request.method == "GET":
        return redirect('/pizza/createPie/')
    Pie.objects.create(
        pieName=request.POST['pieName'],
        pieType=request.POST['pieType'],
        pieStart=request.POST['pieStart'],
        parlor_id=request.POST['parlor']
    )
    return redirect('/pizza/thePies/')

# Landing page to edit 1 pie
def editPie(request, pie_id):
    onePie = Pie.objects.get(id=pie_id)
    context = {
        'editPie': onePie,
        'pizzas': Pizza.objects.all().values(),
    }
    return render(request, 'editPie.html', context)

#hidden route to update Pie ie.)Pie's name
def updatePie(request, pie_id):
    toUpdate= Pie.objects.get(id=pie_id)
    toUpdate.pieName = request.POST['pieName']
    toUpdate.pieType = request.POST['pieType']
    toUpdate.pieStart = request.POST['pieStart']
    toUpdate.pizza_id = request.POST['pizza_id']
    toUpdate.save()

    return redirect('/pizza/thePies/')

#Delete a pie
def deletePie(request, pie_id):
    toDelete = Pie.objects.get(id=pie_id)
    toDelete.delete()

    return redirect('/pizza/thePies/')

#Landing page to view employees
def allEmployees(request):
    context = {
        'pizzas': Pizza.objects.all()
    }
    return render(request, 'allEmployees.html', context)

#Here we create an Employee via a hidden route
def createEmployee(request):
    if request.method == "GET":
        return redirect('/pizza/createEmployee/')
    Employee.objects.create(
        firstName=request.POST['firstName'],
        lastName=request.POST['lastName'],
        email=request.POST['email'],
        pizza_id=request.POST['pizza'],
    )
    return redirect('/pizza/theEmployees/')

#Landing page to edit/update an Employee by pulling up one
def editEmployee(request, employee_id):
    oneEmployee = Employee.objects.get(id=employee_id)
    context = {
        'editEmployee': oneEmployee,
        'pizzas': Pizza.objects.all().values(),
    }
    return render(request, 'editEmployee.html', context)

#hidden route to update Employee ie.)Employee's name
def updateEmployee(request, employee_id):
    toUpdate= Employee.objects.get(id=employee_id)
    toUpdate.firstName = request.POST['firstName']
    toUpdate.lastName = request.POST['lastName']
    toUpdate.email = request.POST['email']
    toUpdate.pizza_id = request.POST['pizza_id']
    toUpdate.save()

    return redirect('/pizza/theEmployees/')

#Delete an employee
def deleteEmployee(request, employee_id):
    toDelete = Employee.objects.get(id=employee_id)
    toDelete.delete()

    return redirect('/pizza/theEmployees/')

# Landing page for Games
def game(request):
    # if request.method == 'post':
    #     errors = Game.objects.validate(request.POST)
    #     if errors:
    #         for err in errors.values():
    #             messages.error(request, err)
    #         return redirect('/pizza/theGames/')
    context = {
        'pizzas': Pizza.objects.all()
    }
    return render(request, 'allGames.html', context)

#Hidden route to create new game
def createGame(request):
    errors = Game.objects.validate(request.POST)
    if errors:
        for err in errors.values():
            messages.error(request, err)
        return redirect('/pizza/theGames/')
    Game.objects.create(
        gameName=request.POST['gameName'],
        pizza_id=request.POST['pizza'],
    )
    return redirect('/pizza/theGames/')

def index(request):
    return render(request, 'index.html')

def login(request):
    user = User.objects.filter(username = request.POST['username'])
    if user:
        userLogin=user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), user.password.endcode()):
            request.session['user_id'] = userLogin.id
            return redirect('/dashboard/')
        messages.error(request, 'Invalid Credentials')
        return redirect('/')
    messages.error(request, 'That Username is not in our system, please register for an account')
    return redirect('/')

def signup(request):
    return render(request, 'register.html')

def register(request):
    if request.method == 'GET':
        return redirect('/signup/')
    errors =  User.objects.validate(request.POST)
    if errors:
        for err in errors.values():
            messages.error(request, err)
        return redirect('/signup/')
    hashedPw = bcrypt.hashpw(request.POST['password'],
    encode(), bycrypt.gensalt()).decode()
    newUser = User.objects.create(
        firstName = request.POST['firstName'],
        lastName = request.POST['lastName'],
        email = request.POST['email'],
        username = request.POST['username'],
        password = hashedPw
    )
    request.session['user_id'] = newUser.id
    return redirect('/dashboard/')

def dashboard(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session
    ['user_id'])
    context = {
        'user': user,
        'notes': Note.objects.all().values()

    }
    return render(request, 'dashboard.html', context)

def logout(request):
    request.session.clear()
    return redirect('/')

def createNote(request):
    Note.objects.create(
        noteTitle = request.POST['noteTitle'],
        noteText = request.POST['noteTitle'],
        user_id=request.POST['user']
    )
    return redirect('/dashboard/')








