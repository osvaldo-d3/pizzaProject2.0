from django.urls import path

from . import views

urlpatterns = [
    path('', views.officialPizza),
    path('thePizzas/', views.allPizzas),
    path('createPizza/', views.createPizza), 
    path('<int:pizza_id>/editPizza/', views.editPizza),
    path('<int:pizza_id>/updatePizza/', views.updatePizza),
    path('<int:pizza_id>/deletePizza/', views.deletePizza),
    path('thePies/', views.allPies),
    path('createPie/', views.createPie),
    path('<int:pie_id>/editPie/', views.editPie),
    path('<int:pie_id>/updatePie/', views.updatePie),
    path('<int:pie_id>/deletePie/', views.deletePie),
    path('theEmployees/', views.allEmployees),
    path('createEmployee/', views.createEmployee), 
    path('<int:employee_id>/editEmployee/', views.editEmployee),
    path('<int:employee_id>/updateEmployee/', views.updateEmployee),
    path('<int:employee_id>/deleteEmployee/', views.deleteEmployee),
    path('theGames/', views.game), 
    path('createGame/', views.createGame),
    path('', views.index),
    path('login/', views.login),
    path('signup/', views.signup),
    path('register/', views.register),
    path('dashboard/', views.dashboard),
    path('logout/', views.logout),
    path('addNote/', views.createNote),
]
